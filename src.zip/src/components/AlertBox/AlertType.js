export default {
  error: 'error',
  info: 'info',
  success: 'success',
};
