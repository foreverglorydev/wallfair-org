export default {
  divider: 'divider',
  emptyLine: 'emptyLine',
  keyValue: 'keyValue',
};
