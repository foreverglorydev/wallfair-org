export default {
  highlightHomeCtaBet: 'highlightHomeCtaBet',
  highlightMenuAddEventOrBet: 'highlightMenuAddEventOrBet',
  highlightSettingsChangeMailAddress: 'highlightSettingsChangeMailAddress',
  highlightSettingsChangePhoneNumber: 'highlightSettingsChangePhoneNumber',
  highlightSettingsChangePushNotification:
    'highlightSettingsChangePushNotification',
  highlightSettingsMyBets: 'highlightSettingsMyBets',
  highlightSettingsMyProfile: 'highlightSettingsMyProfile',
  highlightSettingsMyWallet: 'highlightSettingsMyWallet',
  highlightSettingsSupport: 'highlightSettingsSupport',
  highlightPlaceBet: 'highlightPlaceBet',
  highlightDeposit: 'highlightDeposit',
  highlightModalButton: 'highlightModalButton',
};
