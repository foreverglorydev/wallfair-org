export default {
  fillRed: 'fillRed',
  fillGray: 'fillGray',
};
