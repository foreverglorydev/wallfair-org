export default {
  copyToClipboardInput: 'copyToClipboardInput',
  copyToClipboardInputWhite: 'copyToClipboardInputWhite',
  defaultInput: 'defaultInput',
  coloredBorderMint: 'coloredBorderMint',
  coloredBorderLightPurple: 'coloredBorderLightPurple',
  dashedBorderTransparent: 'dashedBorderTransparent',
  modalInput: 'modalInput',
};
