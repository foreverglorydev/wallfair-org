export default {
  black: 'black',
  primary: 'primary',
  primaryLightTransparent: 'primaryLightTransparent',
  white: 'white',
  notification: 'notification',
};
