export default {
  opacity01: 'opacity01',
  opacity04: 'opacity04',
};
