export default {
  colorOrangeLight: 'colorOrangeLight',
  colorGreen: 'colorGreen',
  colorPinkLight: 'colorPinkLight',
  colorFlamingo: 'colorFlamingo',
};
