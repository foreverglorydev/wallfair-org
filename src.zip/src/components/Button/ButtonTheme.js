export default {
  authenticationScreenButton: 'authenticationScreenButton',
  welcomeScreenButton: 'welcomeScreenButton',
};
