export default {
  twitter: 'twitter',
  facebook: 'facebook',
  whatsapp: 'whatsapp',
};
