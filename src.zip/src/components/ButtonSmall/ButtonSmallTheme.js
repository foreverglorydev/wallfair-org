export default {
  dark: 'dark',
  red: 'red',
  grey: 'grey',
};
