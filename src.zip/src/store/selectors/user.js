export const selectUsers = state => state.user.users;
