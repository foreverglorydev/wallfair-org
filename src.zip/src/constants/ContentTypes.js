const contentTypes = {
  applicationJSON: 'application/json',
};

module.exports = contentTypes;
