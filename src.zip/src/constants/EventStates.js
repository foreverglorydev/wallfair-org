export const EVENT_STATES = {
  ONLINE: 'online',
  OFFLINE: 'offline',
};
