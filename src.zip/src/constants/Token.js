export const TOKEN_NAME = 'WFAIR';
