export default {
  deposit: 'deposit',
  withdrawal: 'withdrawal',
};
