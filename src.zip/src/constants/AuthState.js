const authState = {
  LOGGED_IN: 'LOGGED_IN',
  LOGGED_OUT: 'LOGGED_OUT',
  SMS_SENT: 'SMS_SENT',
  SET_NAME: 'SET_NAME',
  SET_EMAIL: 'SET_EMAIL',
};

module.exports = authState;
