export const CONVERSION_RATES = {
  EUR: 0.2,
  USD: 0.24,
};

export const CURRENCIES = ['WFAIR', 'EUR', 'USD'];
