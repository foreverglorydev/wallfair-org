export default {
  active: 'active',
  canceled: 'canceled',
  closed: 'closed',
  resolved: 'resolved',
};
